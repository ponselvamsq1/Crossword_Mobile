using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
public class CrosswordManagerM : MonoBehaviour
{
    private int count ;
    
    private CrosswordWord currentActiveWord = null;
   
    private Dictionary<TMP_InputField, List<CrosswordWord>> inputFieldToWords = new Dictionary<TMP_InputField, List<CrosswordWord>>();
    private Dictionary<TMP_InputField, int> inputClickState = new Dictionary<TMP_InputField, int>();

    
    [System.Serializable]
       public class CrosswordWord
       {
           public string word;
           public int hintIndex;
           public Vector2Int startPosition;
           public bool isHorizontal;
       }
       public List<CrosswordWord> words;
       public int gridSize ;
       public GameObject cellPrefab;
       public Transform gridParent;
       private Dictionary<Vector2Int, TMP_InputField> gridCells = new Dictionary<Vector2Int, TMP_InputField>();
       
      
       public void StartMediumlevel()
       {
           count = 0;
           GameManager.instance.MediumLevel();
           GameManager.instance.timerRunning = true;
           GenerateGrid();
       }

       public void ClearGrid()
       {
           foreach (Transform child in  gridParent.transform)
           {
               Destroy(child.gameObject);
           }
           
           gridCells.Clear();
           inputFieldToWords.Clear();
           currentActiveWord = null;
       }
       
     // navigation inputfield
  void GenerateGrid()
    {
        ClearGrid();
        int wordIndex = 1;

        for (int x = 0; x < gridSize; x++)
        {
            for (int y = 0; y < gridSize; y++)
            {
                GameObject cell = Instantiate(cellPrefab, gridParent);
                TMP_InputField inputField = cell.GetComponent<TMP_InputField>();
                inputField.characterLimit = 1;
                inputField.text = "";
                inputField.interactable = false;
                gridCells[new Vector2Int(x, y)] = inputField;
            }
        }

        for (int w = 0; w < words.Count; w++)
        {
            CrosswordWord word = words[w];

            for (int i = 0; i < word.word.Length; i++)
            {
                Vector2Int position = word.isHorizontal
                    ? new Vector2Int(word.startPosition.x + i, word.startPosition.y)
                    : new Vector2Int(word.startPosition.x, word.startPosition.y + i);

                if (gridCells.ContainsKey(position))
                {
                    TMP_InputField inputField = gridCells[position];
                    inputField.interactable = true;

                    if (!inputFieldToWords.ContainsKey(inputField))
                        inputFieldToWords[inputField] = new List<CrosswordWord>();

                    inputFieldToWords[inputField].Add(word);

                    if (i == 0)
                    {
                        inputField.transform.GetChild(1).gameObject.SetActive(true);
                        inputField.transform.GetChild(1).GetComponent<TextMeshProUGUI>().text = "" + wordIndex;
                        wordIndex++;
                    }

                    int currentLetterIndex = i;
                    CrosswordWord currentWord = word;

                    // Auto move only within active word
                    inputField.onValueChanged.AddListener((text) =>
                    {
                        if (!string.IsNullOrEmpty(text))
                        {
                            if (currentActiveWord == null) return;

                            int index = -1;
                            for (int i = 0; i < currentActiveWord.word.Length; i++)
                            {
                                Vector2Int pos = currentActiveWord.isHorizontal
                                    ? new Vector2Int(currentActiveWord.startPosition.x + i, currentActiveWord.startPosition.y)
                                    : new Vector2Int(currentActiveWord.startPosition.x, currentActiveWord.startPosition.y + i);

                                if (gridCells.ContainsKey(pos) && gridCells[pos] == inputField)
                                {
                                    index = i;
                                    break;
                                }
                            }

                            if (index == -1) return;

                            // Loop through the word starting from the next letter (and wrap around)
                            for (int offset = 1; offset < currentActiveWord.word.Length; offset++)
                            {
                                int nextIndex = (index + offset) % currentActiveWord.word.Length;

                                Vector2Int nextPos = currentActiveWord.isHorizontal
                                    ? new Vector2Int(currentActiveWord.startPosition.x + nextIndex, currentActiveWord.startPosition.y)
                                    : new Vector2Int(currentActiveWord.startPosition.x, currentActiveWord.startPosition.y + nextIndex);

                                if (gridCells.ContainsKey(nextPos))
                                {
                                    TMP_InputField nextField = gridCells[nextPos];

                                    if (nextField.interactable)
                                    {
                                       // EventSystem.current.SetSelectedGameObject(nextField.gameObject);
                                       // nextField.OnPointerClick(new PointerEventData(EventSystem.current));
                                       StartCoroutine(SelectNextField(nextField));
                                        break;
                                    }
                                }
                            }
                        }

                    });
                    
                    // Highlight word on select
                    EventTrigger trigger = inputField.GetComponent<EventTrigger>();
                    if (trigger == null)
                        trigger = inputField.gameObject.AddComponent<EventTrigger>();

                    EventTrigger.Entry entry = new EventTrigger.Entry();
                    entry.eventID = EventTriggerType.PointerClick; // Use PointerClick to catch actual clicks

                    entry.callback.AddListener((BaseEventData data) =>
                    {
                        TMP_InputField selectedInput = inputField;

                        if (!inputFieldToWords.ContainsKey(selectedInput))
                            return;

                        List<CrosswordWord> relatedWords = inputFieldToWords[selectedInput];

                        if (relatedWords.Count == 1)
                        {
                            currentActiveWord = relatedWords[0];
                            HighlightWord(currentActiveWord);
                        }
                        else if (relatedWords.Count == 2)
                        {
                            // Toggle between the two words on each click
                            if (!inputClickState.ContainsKey(selectedInput))
                                inputClickState[selectedInput] = 0;

                            int toggleIndex = inputClickState[selectedInput];
                            currentActiveWord = relatedWords[toggleIndex];
                            inputClickState[selectedInput] = 1 - toggleIndex;

                            HighlightWord(currentActiveWord);
                        }
                    });
                    trigger.triggers.Add(entry);

                }
            }
        }
        
        
    }

    
    /// <summary>
    ///  normal highlight
    /// </summary>
    /// <param name="wordToHighlight"></param>
    private void HighlightWord(CrosswordWord wordToHighlight, bool clearBefore = true)
    {
        if (clearBefore)
        {
            foreach (var kvp in gridCells)
            {
                kvp.Value.image.color = Color.white;
            }
        }

        for (int i = 0; i < wordToHighlight.word.Length; i++)
        {
            Vector2Int pos = wordToHighlight.isHorizontal
                ? new Vector2Int(wordToHighlight.startPosition.x + i, wordToHighlight.startPosition.y)
                : new Vector2Int(wordToHighlight.startPosition.x, wordToHighlight.startPosition.y + i);

            if (gridCells.ContainsKey(pos))
            {
                gridCells[pos].image.color = new Color(1f, 0.92f, 0.6f); // Light yellow
            }
        }
    }

    
   

    public void CheckAnswers()
    {
        bool allCorrect = true;

        foreach (var word in words)
        {
            string playerAnswer = "";
            List<TMP_InputField> letterFields = new List<TMP_InputField>();

            for (int i = 0; i < word.word.Length; i++)
            {
                Vector2Int position = word.isHorizontal
                    ? new Vector2Int(word.startPosition.x + i, word.startPosition.y)
                    : new Vector2Int(word.startPosition.x, word.startPosition.y + i);

                if (gridCells.ContainsKey(position))
                {
                    TMP_InputField inputField = gridCells[position];
                    playerAnswer += inputField.text.ToUpper();
                    letterFields.Add(inputField);
                }
            }

            if (playerAnswer == "")
            {
                allCorrect = false;
            }
            else
            {
                if (playerAnswer == word.word.ToUpper())
                {
                    Debug.Log("Correct: " + word.word);
                    count++;

                    foreach (TMP_InputField inputField in letterFields)
                    {
                        inputField.image.color = Color.green;
                        inputField.textComponent.color = Color.white;
                    }
                }
                else
                {
                    allCorrect = false;
                }
            }
        }

        if (count >= words.Count && allCorrect)
        {
            GameManager.instance.EnableEasyWinpanel();
            GameManager.instance.timerRunning = false;
            GameManager.instance.playagainbtn.SetActive(true);
        }
        else if (!allCorrect)
        {
            GameManager.instance.EnableTryagain();
        }
    }

    public void ShowHint()
    {
        foreach (var word in words)
        {
            if (word.hintIndex < 0 || word.hintIndex >= word.word.Length)
            {
                Debug.LogWarning("Invalid hint index for word: " + word.word);
                continue;
            }
    
            Vector2Int position = word.isHorizontal
                ? new Vector2Int(word.startPosition.x + word.hintIndex, word.startPosition.y)
                : new Vector2Int(word.startPosition.x, word.startPosition.y + word.hintIndex);
    
            if (gridCells.ContainsKey(position))
            {
                TMP_InputField inputField = gridCells[position];
                char correctLetter = word.word[word.hintIndex];
    
                if (inputField.text.ToUpper() == correctLetter.ToString().ToUpper())
                    continue;
    
                inputField.text = correctLetter.ToString();
                inputField.interactable = false; // Important for navigation
                inputField.textComponent.color = Color.blue;
                inputField.GetComponent<TMP_InputField>().enabled = false; 
            }
        }
    }
    
    IEnumerator SelectNextField(TMP_InputField nextField)
    {
        yield return null; // wait 1 frame

        EventSystem.current.SetSelectedGameObject(null);

        yield return null;

        nextField.Select();
        nextField.ActivateInputField();
    }

  

}